from flask import Flask, render_template, request
app = Flask(__name__)
# our index route will handle rendering our form
@app.route('/')
def index():
  return render_template("index.html")
# this route will handle our form submission
# notice how we defined which HTTP methods are allowed by this route
@app.route('/users', methods=['POST'])
def create_user():

   # we'll talk about the following two lines after we learn a little more
   # about forms
   a = request.form['name']
   b = request.form['location']
   c = request.form['language']

   # redirects back to the '/' route
   return render_template('index1.html', name = a, location = b, language = c)
app.run(debug=True) # run our server
